//
//  interfaces.h
//  EjemploObjectiveC
//
//  Created by jpaniagua on 3/12/20.
//  Copyright © 2020 jpaniagua. All rights reserved.
//

#ifndef interfaces_h
#define interfaces_h



#endif /* interfaces_h */
