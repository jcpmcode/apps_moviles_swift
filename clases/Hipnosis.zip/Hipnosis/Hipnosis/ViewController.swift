//
//  ViewController.swift
//  Hipnosis
//
//  Created by molascoaga on 2/20/20.
//  Copyright © 2020 molascoaga. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    var campoDeTexto : UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let anchoDelCampoDeTexto = self.view.bounds.width * 0.75
        let origenDelCampoDeTextoX = (self.view.bounds.width - anchoDelCampoDeTexto) / 2
        let rectCampoDeTexto = CGRect(x: origenDelCampoDeTextoX, y: -30, width: anchoDelCampoDeTexto, height: 30)
        
        self.campoDeTexto = UITextField(frame: rectCampoDeTexto)
        self.campoDeTexto.backgroundColor = .white
        self.campoDeTexto.borderStyle = .roundedRect
        self.campoDeTexto.placeholder = "Hipnotisate"
        self.campoDeTexto.returnKeyType = .google
        self.campoDeTexto.delegate = self
        
        self.view.addSubview(campoDeTexto)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 2.0, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 0, options: .layoutSubviews, animations: {
            self.campoDeTexto.frame.origin.y = 30
        }, completion: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("Presionaron return")
        print("Teclearon el texto: \(textField.text!)")
        self.ponMensajes(mensaje: textField.text!)
        textField.text = ""
        textField.placeholder = "Hipnotizate"
        textField.resignFirstResponder()
        return true
    }
    
    func ponMensajes(mensaje: String) {
        for _ in 0..<20 {
            let label = UILabel()
            label.backgroundColor = .clear
            label.textColor = .systemPink
            label.text = mensaje
            label.sizeToFit()
            let anchoDisponible = self.view.bounds.maxX - label.bounds.size.width
            let coordenadaX = CGFloat.random(in: 0..<anchoDisponible)
            let finDeCampoDeTextoVertical = (self.campoDeTexto.frame.origin.y + self.campoDeTexto.bounds.size.height)
            let alturaDisponible = self.view.bounds.maxY - label.bounds.size.height
            let coordenadaY = CGFloat.random(in: finDeCampoDeTextoVertical..<alturaDisponible)
            label.frame.origin = CGPoint(x: coordenadaX, y: coordenadaY)
            self.view.addSubview(label)
            label.alpha = 0
            UIView.animate(withDuration: 3.0, animations: {
                label.alpha = 1
            } ) // Esta funcion recibe un closure
            UIView.animateKeyframes(withDuration: 1.0, delay: 3.0, options: .layoutSubviews, animations: {
                UIView.addKeyframe(withRelativeStartTime: 0, relativeDuration: 0, animations: {
                    label.center = self.view.center
                })
                UIView.addKeyframe(withRelativeStartTime: 0.8, relativeDuration: 0.2, animations: {
                    label.frame.origin = CGPoint(x: CGFloat.random(in: 0..<anchoDisponible), y: CGFloat.random(in: finDeCampoDeTextoVertical..<alturaDisponible))
                })
            }, completion: nil)
        }
    }
    
}

